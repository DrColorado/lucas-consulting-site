Tic Tac Toe

Almost all of us played this game as kids, sometimes with chalk on the sidewalk, on a napkin, or even on fogged-up glass in our station wagon. We wrote this app and offered it free-of-charge to classrooms years ago, when we were still known as 'Lucas Consulting Services.' We designed the program to allow for a two player game, or for a single user to play against the computer using a very simple form of Artificial Intelligence. As an exercise in understanding strategy and critical thinking, the app also allows the user to toggle a tool ON or OFF to show the order of each move for each player in real-time to better understand the path to winning each game. We think it's an entertaining and very old game that still provides an interesting challenge for all ages. We were told this was a classroom favorite.  Enjoy!

Lucas Consultant Services LLC
www.LucasConsultantServices.com
